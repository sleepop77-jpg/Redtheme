package com.red.os

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.sin
import kotlin.random.Random

object Ambience {
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    @Volatile private var running = false
    var mode = "OFF"

    fun set(m: String) {
        mode = m
        stop()
        if (m != "OFF") start(m)
    }

    private fun start(m: String) {
        val rate = 22050
        val bufSize = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (bufSize <= 0) return
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(bufSize * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = at; at.play(); running = true
        thread = Thread {
            val rnd = Random(7); val buf = ShortArray(bufSize / 2)
            var brown = 0.0; var drop = 0.0; var t = 0L
            while (running) {
                for (i in buf.indices) {
                    t++
                    val w = rnd.nextDouble() * 2 - 1
                    val s = if (m == "RAIN") {
                        if (rnd.nextDouble() < 0.0004) drop = 1.0
                        drop *= 0.996
                        w * 0.12 + drop * w * 0.5
                    } else {
                        brown = (brown + 0.02 * w) / 1.02
                        brown * 3.0 + 0.08 * sin(2 * Math.PI * 46 * t / rate)
                    }
                    buf[i] = (s.coerceIn(-1.0, 1.0) * 32767 * 0.6).toInt().toShort()
                }
                at.write(buf, 0, buf.size)
            }
        }.apply { start() }
    }

    fun stop() {
        running = false
        try { thread?.join(300) } catch (_: Exception) { }
        try { track?.stop(); track?.release() } catch (_: Exception) { }
        track = null; thread = null
    }
}