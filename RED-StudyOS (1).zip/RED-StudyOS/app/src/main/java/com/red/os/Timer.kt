package com.red.os

import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun Timer(running: Boolean, elapsed: Int, planned: Int, onRunning: (Boolean) -> Unit, onElapsed: (Int) -> Unit, onPlanned: (Int) -> Unit) {
    val ctx = LocalContext.current
    val pulse = rememberInfiniteTransition()
    val beat by pulse.animateFloat(1f, 1.035f, infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse))
    val prog = (elapsed.toFloat() / (planned * 60f)).coerceIn(0f, 1f)

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 15, 25, 45, 60, 90).forEach { m ->
                Box(Modifier.glass().clickable { if (!running) { onPlanned(m); onElapsed(0) } }.padding(horizontal = 13.dp, vertical = 9.dp)) {
                    Text("$m", color = if (planned == m) AMBER else SOFT, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(280.dp)) {
                drawCircle(Color(0x30FFFFFF), style = Stroke(12.dp.toPx()))
                drawArc(AMBER.copy(alpha = 0.25f), -90f, 360f * prog, true, style = Stroke(22.dp.toPx(), cap = StrokeCap.Round))
                drawArc(AMBER, -90f, 360f * prog, true, style = Stroke(12.dp.toPx(), cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer { scaleX = if (running) beat else 1f; scaleY = if (running) beat else 1f }) {
                Text(fmt(elapsed), color = WHITE, fontSize = 58.sp, fontWeight = FontWeight.ExtraBold)
                Text("OF $planned MIN", color = SOFT, fontSize = 11.sp, letterSpacing = 3.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Box(Modifier.glass().size(56.dp).clickable { onElapsed(0); onRunning(false) }, contentAlignment = Alignment.Center) { Ic("reset", SOFT, 22) }
            Box(Modifier.glass().size(88.dp).clickable { onRunning(!running) }, contentAlignment = Alignment.Center) {
                Ic(if (running) "pause" else "play", WHITE, 36)
            }
            Box(Modifier.glass().size(56.dp).clickable {
                onRunning(false)
                if (elapsed >= 60) {
                    val min = elapsed / 60
                    E.addSession(min)
                    Toast.makeText(ctx, "HELD FOR $min MIN.", Toast.LENGTH_LONG).show()
                } else Toast.makeText(ctx, "UNDER A MINUTE. NOT COUNTED.", Toast.LENGTH_LONG).show()
                onElapsed(0)
            }, contentAlignment = Alignment.Center) { Ic("stop", SOFT, 22) }
        }
        Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Amb("OFF", "stop"); Amb("RAIN", "rain"); Amb("DEEP", "waves") }
        Spacer(Modifier.weight(1f))
        Text("TODAY ${E.todayMin()} / ${E.goal()} MIN", color = SOFT, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
fun Amb(mode: String, icon: String) {
    Box(Modifier.glass().clickable { Ambience.set(mode) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Ic(icon, if (Ambience.mode == mode) AMBER else SOFT, 16)
            Text(mode, color = if (Ambience.mode == mode) AMBER else SOFT, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
    }
}

fun fmt(s: Int): String {
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%02d:%02d", m, sec)
}