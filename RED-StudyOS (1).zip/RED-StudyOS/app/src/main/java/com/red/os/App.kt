package com.red.os

import android.widget.Toast
import androidx.compose.animation.animateFloatAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

val WHITE = Color(0xFFFFFFFF)
val SOFT = Color(0xCCFFE3DC)
val AMBER = Color(0xFFFFB35C)

fun Modifier.glass() = this
    .background(Color(0x2EFFFFFF), RoundedCornerShape(26))
    .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(26))

@Composable
fun Root() {
    val ctx = LocalContext.current
    var splash by remember { mutableStateOf(true) }
    var tab by remember { mutableStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var elapsed by remember { mutableStateOf(0) }
    var planned by remember { mutableStateOf(25) }

    val inf = rememberInfiniteTransition()
    val breathe by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Reverse))
    val grab = if (running || elapsed > 0) (elapsed.toFloat() / (planned * 60f)).coerceIn(0f, 1f) else breathe * 0.12f

    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            elapsed++
            if (elapsed >= planned * 60) {
                running = false
                E.addSession(planned)
                Toast.makeText(ctx, "HELD FOR $planned MIN. RELEASED.", Toast.LENGTH_LONG).show()
                elapsed = 0
            }
        }
    }
    DisposableEffect(Unit) { onDispose { Ambience.stop() } }

    Box(Modifier.fillMaxSize()) {
        Backdrop(grab)
        if (splash) Splash { splash = false }
        else Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("hand", WHITE, 24)
                Spacer(Modifier.width(8.dp))
                Text("RED", color = WHITE, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 6.sp)
                Spacer(Modifier.weight(1f))
                Ic("flame", AMBER, 18)
                Spacer(Modifier.width(4.dp))
                Text("${E.streak()}", color = SOFT, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> Timer(running, elapsed, planned, { running = it }, { elapsed = it }, { planned = it })
                    1 -> Stats()
                    2 -> Settings()
                }
            }
            Row(Modifier.glass().fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Nav("clock", "TIMER", tab == 0) { tab = 0 }
                Nav("chart", "STATS", tab == 1) { tab = 1 }
                Nav("gear", "SET", tab == 2) { tab = 2 }
            }
        }
    }
}

@Composable
fun Nav(icon: String, label: String, on: Boolean, click: () -> Unit) {
    val pulse = rememberInfiniteTransition()
    val a by pulse.animateFloat(0.7f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse))
    Column(Modifier.clickable { click() }.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Ic(icon, if (on) WHITE else Color(0x80FFE3DC), 22)
        Text(label, color = if (on) WHITE else Color(0x80FFE3DC).copy(alpha = a), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    }
}

@Composable
fun Splash(done: () -> Unit) {
    val scale by animateFloatAsState(targetValue = 1f, animationSpec = tween(1200))
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("RED", color = WHITE, fontSize = 64.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 14.sp,
            modifier = Modifier.graphicsLayer { scaleX = 0.8f + scale * 0.2f; scaleY = 0.8f + scale * 0.2f; alpha = scale })
        Text("THE TIMER THAT HOLDS YOU", color = SOFT, fontSize = 11.sp, letterSpacing = 4.sp)
        Spacer(Modifier.height(48.dp))
        Box(Modifier.glass().clickable { done() }.padding(horizontal = 42.dp, vertical = 16.dp)) {
            Text("BEGIN", color = WHITE, fontWeight = FontWeight.ExtraBold, letterSpacing = 6.sp, fontSize = 15.sp)
        }
    }
}