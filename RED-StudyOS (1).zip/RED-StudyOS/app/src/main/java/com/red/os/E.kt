package com.red.os

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object E {
    lateinit var p: SharedPreferences
    fun init(c: Context) { p = c.getSharedPreferences("red", Context.MODE_PRIVATE) }
    fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun day(off: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(System.currentTimeMillis() - off * 86400000L))
    fun todayMin() = p.getInt("t_" + today(), 0)
    fun total() = p.getInt("total", 0)
    fun sessions() = p.getInt("sessions", 0)
    fun streak() = p.getInt("streak", 0)
    fun goal() = p.getInt("goal", 120)
    fun setGoal(v: Int) = p.edit().putInt("goal", v).apply()
    fun addSession(min: Int) {
        val ls = p.getString("lastDay", "")
        val st = when {
            ls == today() -> maxOf(streak(), 1)
            ls == day(1) -> streak() + 1
            else -> 1
        }
        p.edit()
            .putInt("t_" + today(), todayMin() + min)
            .putInt("total", total() + min)
            .putInt("sessions", sessions() + 1)
            .putInt("streak", st)
            .putString("lastDay", today())
            .apply()
    }
    fun week(): List<Int> = (6 downTo 0).map { p.getInt("t_" + day(it.toLong()), 0) }
    fun wipe() = p.edit().clear().apply()
}