package com.red.os

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Settings() {
    val ctx = LocalContext.current
    var arm by remember { mutableStateOf(0L) }
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.glass().fillMaxWidth().padding(18.dp)) {
            Text("DAILY GOAL", color = SOFT, fontSize = 11.sp, letterSpacing = 3.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.glass().size(46.dp).clickable { E.setGoal((E.goal() - 15).coerceAtLeast(15)) }, contentAlignment = Alignment.Center) { Ic("minus", SOFT, 18) }
                Text("${E.goal()} MIN", color = WHITE, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Box(Modifier.glass().size(46.dp).clickable { E.setGoal((E.goal() + 15).coerceAtLeast(15)) }, contentAlignment = Alignment.Center) { Ic("plus", SOFT, 18) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.glass().fillMaxWidth().padding(18.dp)) {
            Text("ABOUT THE GRIP", color = SOFT, fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(8.dp))
            Text("RED holds your attention behind the glass. Start a shift and the hand closes with your progress. Finish and it lets go.", color = WHITE, fontSize = 12.sp, lineHeight = 20.sp)
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.glass().fillMaxWidth().clickable {
            val now = System.currentTimeMillis()
            if (now - arm > 3000) { arm = now; Toast.makeText(ctx, "TAP AGAIN TO ERASE.", Toast.LENGTH_LONG).show() }
            else { E.wipe(); Toast.makeText(ctx, "ERASED.", Toast.LENGTH_LONG).show() }
        }.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Ic("trash", Color(0xFFFF6B6B), 20)
                Text("ERASE ALL RECORDS", color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 2.sp)
            }
        }
    }
}