package com.red.os

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun Ic(name: String, color: Color = Color.White, dp: Int = 22) {
    Canvas(Modifier.size(dp.dp)) {
        val w = size.width; val h = size.height
        val sw = w / 10f
        when (name) {
            "play" -> {
                val p = Path()
                p.moveTo(w * 0.28f, h * 0.16f); p.lineTo(w * 0.84f, h * 0.5f); p.lineTo(w * 0.28f, h * 0.84f); p.close()
                drawPath(p, color)
            }
            "pause" -> {
                drawRect(color, Offset(w * 0.24f, h * 0.18f), Size(w * 0.18f, h * 0.64f))
                drawRect(color, Offset(w * 0.58f, h * 0.18f), Size(w * 0.18f, h * 0.64f))
            }
            "stop" -> drawRoundRect(color, Offset(w * 0.24f, h * 0.24f), Size(w * 0.52f, h * 0.52f), CornerRadius(w * 0.08f))
            "reset" -> {
                drawArc(color, 40f, 280f, true, Offset(w * 0.12f, h * 0.12f), Size(w * 0.76f, h * 0.76f), style = Stroke(sw * 0.8f, cap = StrokeCap.Round))
                val p = Path()
                p.moveTo(w * 0.62f, h * 0.02f); p.lineTo(w * 0.92f, h * 0.16f); p.lineTo(w * 0.66f, h * 0.34f); p.close()
                drawPath(p, color)
            }
            "clock" -> {
                drawOval(color, Offset(w * 0.1f, h * 0.1f), Size(w * 0.8f, h * 0.8f), style = Stroke(sw * 0.8f))
                drawLine(color, Offset(w * 0.5f, h * 0.5f), Offset(w * 0.5f, h * 0.26f), sw * 0.8f, StrokeCap.Round)
                drawLine(color, Offset(w * 0.5f, h * 0.5f), Offset(w * 0.7f, h * 0.58f), sw * 0.8f, StrokeCap.Round)
            }
            "chart" -> {
                drawRoundRect(color, Offset(w * 0.16f, h * 0.5f), Size(w * 0.16f, h * 0.36f), CornerRadius(w * 0.05f))
                drawRoundRect(color, Offset(w * 0.42f, h * 0.26f), Size(w * 0.16f, h * 0.6f), CornerRadius(w * 0.05f))
                drawRoundRect(color, Offset(w * 0.68f, h * 0.62f), Size(w * 0.16f, h * 0.24f), CornerRadius(w * 0.05f))
            }
            "gear" -> {
                drawOval(color, Offset(w * 0.26f, h * 0.26f), Size(w * 0.48f, h * 0.48f), style = Stroke(sw * 0.8f))
                for (i in 0 until 8) {
                    val p = Path(); p.addRect(Rect(w * 0.44f, h * 0.02f, w * 0.56f, h * 0.18f))
                    p.transform(Matrix().apply { translate(w / 2, h / 2); rotateZ(i * 45f); translate(-w / 2, -h / 2) })
                    drawPath(p, color)
                }
            }
            "flame" -> {
                val p = Path()
                p.moveTo(w * 0.5f, h * 0.08f)
                p.quadraticBezierTo(w * 0.82f, h * 0.42f, w * 0.74f, h * 0.66f)
                p.quadraticBezierTo(w * 0.66f, h * 0.92f, w * 0.5f, h * 0.92f)
                p.quadraticBezierTo(w * 0.34f, h * 0.92f, w * 0.26f, h * 0.66f)
                p.quadraticBezierTo(w * 0.2f, h * 0.44f, w * 0.5f, h * 0.08f)
                p.close()
                drawPath(p, color)
            }
            "rain" -> {
                drawCircle(color, w * 0.2f, center = Offset(w * 0.36f, h * 0.4f))
                drawCircle(color, w * 0.22f, center = Offset(w * 0.6f, h * 0.36f))
                drawRect(color, Offset(w * 0.2f, h * 0.36f), Size(w * 0.55f, h * 0.22f))
                drawLine(color, Offset(w * 0.3f, h * 0.68f), Offset(w * 0.26f, h * 0.88f), sw * 0.7f, StrokeCap.Round)
                drawLine(color, Offset(w * 0.52f, h * 0.68f), Offset(w * 0.48f, h * 0.88f), sw * 0.7f, StrokeCap.Round)
                drawLine(color, Offset(w * 0.74f, h * 0.68f), Offset(w * 0.7f, h * 0.88f), sw * 0.7f, StrokeCap.Round)
            }
            "waves" -> {
                for (k in 0..2) {
                    val y = h * (0.3f + k * 0.2f)
                    val p = Path()
                    p.moveTo(w * 0.1f, y)
                    p.quadraticBezierTo(w * 0.3f, y - h * 0.12f, w * 0.5f, y)
                    p.quadraticBezierTo(w * 0.7f, y + h * 0.12f, w * 0.9f, y)
                    drawPath(p, color, style = Stroke(sw * 0.7f, cap = StrokeCap.Round))
                }
            }
            "plus" -> {
                drawLine(color, Offset(w * 0.5f, h * 0.2f), Offset(w * 0.5f, h * 0.8f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.2f, h * 0.5f), Offset(w * 0.8f, h * 0.5f), sw, StrokeCap.Round)
            }
            "minus" -> drawLine(color, Offset(w * 0.2f, h * 0.5f), Offset(w * 0.8f, h * 0.5f), sw, StrokeCap.Round)
            "trash" -> {
                drawRoundRect(color, Offset(w * 0.26f, h * 0.3f), Size(w * 0.48f, h * 0.56f), CornerRadius(w * 0.06f))
                drawLine(color, Offset(w * 0.18f, h * 0.26f), Offset(w * 0.82f, h * 0.26f), sw * 0.8f, StrokeCap.Round)
                drawLine(color, Offset(w * 0.4f, h * 0.14f), Offset(w * 0.6f, h * 0.14f), sw * 0.8f, StrokeCap.Round)
            }
            "hand" -> {
                drawRoundRect(color, Offset(w * 0.3f, h * 0.42f), Size(w * 0.4f, h * 0.5f), CornerRadius(w * 0.16f))
                for (i in 0..4) {
                    val x = w * (0.28f + i * 0.11f)
                    drawRoundRect(color, Offset(x, h * (if (i == 0 || i == 4) 0.3f else 0.12f)), Size(w * 0.08f, h * 0.4f), CornerRadius(w * 0.04f))
                }
            }
        }
    }
}