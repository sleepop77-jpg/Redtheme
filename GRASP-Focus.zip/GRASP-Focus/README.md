# GRASP — the timer that holds you.
Red glassmorphism. Live grab-hand animation (grip closes with session progress).
No emojis; all icons are vectors. Ambience synthesized on device.