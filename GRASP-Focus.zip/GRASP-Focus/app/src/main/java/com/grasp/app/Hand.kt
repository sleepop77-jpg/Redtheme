package com.grasp.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.graphics.Path

@Composable
fun Backdrop(grab: Float) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFFD93030), Color(0xFF8A1116), Color(0xFF2B0406))))
        drawRect(Brush.radialGradient(listOf(Color(0x00000000), Color(0xAA000000)), center = Offset(w / 2, h / 2), radius = w))
        hand(Color(0xFFE8483C).copy(alpha = 0.85f), grab)
        hand(Color(0xFFFF7A5C).copy(alpha = 0.18f), grab)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.hand(c: Color, grab: Float) {
    val w = size.width; val h = size.height
    val cx = w / 2; val cy = h * 0.60f; val s = w / 420f
    drawOval(c, Rect(cx - 95 * s, cy - 75 * s, cx + 95 * s, cy + 150 * s))
    drawRoundRect(c, Offset(cx - 60 * s, cy - 30 * s), Size(120 * s, 130 * s), CornerRadius(45 * s))
    drawRoundRect(c, Offset(cx - 42 * s, cy + 80 * s), Size(84 * s, 300 * s), CornerRadius(40 * s))
    val fx = listOf(-46f, -23f, 0f, 23f, 46f)
    val fl = listOf(95f, 122f, 132f, 116f, 82f)
    fx.forEachIndexed { i, ox ->
        val spread = ox * (1f - grab * 0.55f)
        val len = fl[i] * (1f - grab * 0.38f)
        val px = cx + spread * s; val py = cy - 15 * s
        val p = Path()
        p.addRoundRect(androidx.compose.ui.graphics.RoundRect(px - 11 * s, py - len * s, px + 11 * s, py + 45 * s, CornerRadius(11 * s)))
        p.transform(Matrix().apply { translate(px, py); rotateZ(spread * 0.55f); translate(-px, -py) })
        drawPath(p, c)
    }
    val tp = Path()
    tp.addRoundRect(androidx.compose.ui.graphics.RoundRect(cx - 100 * s, cy - 5 * s, cx - 74 * s, cy + 85 * s, CornerRadius(13 * s)))
    tp.transform(Matrix().apply { translate(cx - 70 * s, cy + 10 * s); rotateZ(-28f - grab * 22f); translate(-(cx - 70 * s), -(cy + 10 * s)) })
    drawPath(tp, c)
}