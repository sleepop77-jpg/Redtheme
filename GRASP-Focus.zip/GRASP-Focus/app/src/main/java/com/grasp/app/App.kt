package com.grasp.app

import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

val WHITE = Color(0xFFFFFFFF)
val SOFT = Color(0xCCFFE3DC)
val AMBER = Color(0xFFFFB35C)

fun Modifier.glass() = this
    .background(Color(0x2EFFFFFF), RoundedCornerShape(26))
    .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(26))

@Composable
fun App() {
    var tab by remember { mutableStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var elapsed by remember { mutableStateOf(0) }
    var planned by remember { mutableStateOf(25) }

    val idle = rememberInfiniteTransition()
    val breathe by idle.animateFloat(0f, 1f, infiniteRepeatable(tween(3800, easing = LinearEasing), RepeatMode.Reverse))
    val grab = if (running || elapsed > 0) (elapsed.toFloat() / (planned * 60f)).coerceIn(0f, 1f) else breathe * 0.12f

    LaunchedEffect(running) {
        while (running) { delay(1000); elapsed++ }
    }
    DisposableEffect(Unit) { onDispose { Ambience.stop() } }

    Box(Modifier.fillMaxSize()) {
        Backdrop(grab)
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("hand", WHITE, 26)
                Spacer(Modifier.width(10.dp))
                Text("GRASP", color = WHITE, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
                Spacer(Modifier.weight(1f))
                Text("STREAK " + E.streak(), color = SOFT, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp))
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> Timer(running, elapsed, planned,
                        onRunning = { running = it }, onElapsed = { elapsed = it }, onPlanned = { planned = it })
                    1 -> Stats()
                    2 -> Settings()
                }
            }
            Row(Modifier.glass().fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                NavIc("clock", "TIMER", tab == 0) { tab = 0 }
                NavIc("chart", "STATS", tab == 1) { tab = 1 }
                NavIc("gear", "SET", tab == 2) { tab = 2 }
            }
        }
    }
}

@Composable
fun NavIc(icon: String, label: String, on: Boolean, click: () -> Unit) {
    Column(Modifier.clickable { click() }.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Ic(icon, if (on) WHITE else Color(0x80FFE3DC), 22)
        Text(label, color = if (on) WHITE else Color(0x80FFE3DC), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    }
}

@Composable
fun Timer(running: Boolean, elapsed: Int, planned: Int, onRunning: (Boolean) -> Unit, onElapsed: (Int) -> Unit, onPlanned: (Int) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(270.dp)) {
                drawCircle(Color(0x30FFFFFF), style = Stroke(10.dp.toPx()))
                val prog = (elapsed.toFloat() / (planned * 60f)).coerceIn(0f, 1f)
                drawArc(AMBER, -90f, 360f * prog, true, style = Stroke(10.dp.toPx(), cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(fmt(elapsed), color = WHITE, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                Text("OF " + planned + " MIN", color = SOFT, fontSize = 11.sp, letterSpacing = 3.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 25, 45, 60, 90).forEach { m ->
                Box(Modifier.glass().clickable { if (!running) { onPlanned(m); onElapsed(0) } }.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text("$m", color = if (planned == m) AMBER else SOFT, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Box(Modifier.glass().size(58.dp).clickable { onElapsed(0); onRunning(false) }, contentAlignment = Alignment.Center) { Ic("reset", SOFT, 22) }
            Box(Modifier.glass().size(84.dp).clickable { onRunning(!running) }, contentAlignment = Alignment.Center) {
                Ic(if (running) "pause" else "play", WHITE, 34)
            }
            Box(Modifier.glass().size(58.dp).clickable {
                onRunning(false)
                if (elapsed >= 60) {
                    val min = elapsed / 60
                    E.addSession(min)
                    Toast.makeText(ctx, "HELD FOR $min MIN. THE HAND REMEMBERS.", Toast.LENGTH_LONG).show()
                } else Toast.makeText(ctx, "UNDER A MINUTE. THE HAND DID NOT FEEL THAT.", Toast.LENGTH_LONG).show()
                onElapsed(0)
            }, contentAlignment = Alignment.Center) { Ic("stop", SOFT, 22) }
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Amb("OFF", "stop"); Amb("RAIN", "rain"); Amb("DEEP", "waves")
        }
        Spacer(Modifier.weight(1f))
        Text("DAILY GOAL " + E.goal() + " MIN - TODAY " + E.todayMin() + " MIN", color = SOFT, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun Amb(mode: String, icon: String) {
    Box(Modifier.glass().clickable { Ambience.set(mode) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Ic(icon, if (Ambience.mode == mode) AMBER else SOFT, 16)
            Text(mode, color = if (Ambience.mode == mode) AMBER else SOFT, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun Stats() {
    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("flame", "STREAK", "${E.streak()}")
            StatCard("clock", "TODAY", "${E.todayMin()}m")
            StatCard("chart", "TOTAL", "${E.total() / 60}h ${E.total() % 60}m")
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.glass().fillMaxWidth().padding(18.dp)) {
            Text("LAST 7 DAYS", color = SOFT, fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(10.dp))
            Canvas(Modifier.fillMaxWidth().height(140.dp)) {
                val data = E.week()
                val max = (data.maxOrNull() ?: 1).coerceAtLeast(1)
                val slot = size.width / 7f
                data.forEachIndexed { i, v ->
                    val bh = (size.height - 8f) * v / max
                    drawRoundRect(if (v > 0) AMBER else Color(0x30FFFFFF),
                        Offset(i * slot + slot * 0.22f, size.height - bh),
                        Size(slot * 0.56f, bh.coerceAtLeast(4f)),
                        androidx.compose.ui.geometry.CornerRadius(8f))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.glass().fillMaxWidth().padding(18.dp)) {
            Text("SESSIONS HELD: " + E.sessions(), color = WHITE, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text("THE HAND CLOSES AS YOU FOCUS. LET IT HOLD THE WHOLE SHIFT.", color = SOFT, fontSize = 11.sp)
        }
    }
}

@Composable
fun StatCard(icon: String, label: String, value: String) {
    Column(Modifier.glass().weight(1f).padding(16.dp)) {
        Ic(icon, AMBER, 20)
        Spacer(Modifier.height(8.dp))
        Text(value, color = WHITE, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = SOFT, fontSize = 9.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun Settings() {
    val ctx = LocalContext.current
    var arm by remember { mutableStateOf(0L) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.glass().fillMaxWidth().padding(18.dp)) {
            Text("DAILY GOAL", color = SOFT, fontSize = 11.sp, letterSpacing = 3.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.glass().size(46.dp).clickable { E.setGoal((E.goal() - 15).coerceAtLeast(15)) }, contentAlignment = Alignment.Center) { Ic("minus", SOFT, 18) }
                Text("${E.goal()} MIN", color = WHITE, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Box(Modifier.glass().size(46.dp).clickable { E.setGoal((E.goal() + 15).coerceAtLeast(15)) }, contentAlignment = Alignment.Center) { Ic("plus", SOFT, 18) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.glass().fillMaxWidth().padding(18.dp)) {
            Text("ABOUT THE GRIP", color = SOFT, fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(8.dp))
            Text("GRASP holds your attention the way the poster hand holds the glass. Start a shift and the grip closes with your progress. Finish and it lets go. Leave early and it stays open, waiting.", color = WHITE, fontSize = 12.sp, lineHeight = 20.sp)
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.glass().fillMaxWidth().clickable {
            val now = System.currentTimeMillis()
            if (now - arm > 3000) { arm = now; Toast.makeText(ctx, "TAP AGAIN TO ERASE EVERY RECORD.", Toast.LENGTH_LONG).show() }
            else { E.wipe(); Toast.makeText(ctx, "ERASED. THE HAND FORGETS.", Toast.LENGTH_LONG).show() }
        }.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Ic("trash", Color(0xFFFF6B6B), 20)
                Text("ERASE ALL RECORDS", color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 2.sp)
            }
        }
    }
}

fun fmt(s: Int): String {
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%02d:%02d", m, sec)
}