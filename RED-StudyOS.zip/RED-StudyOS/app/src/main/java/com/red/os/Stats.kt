package com.red.os

import androidx.compose.animation.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Stats() {
    Column(Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Card("flame", "STREAK", "${E.streak()}")
            Card("clock", "TODAY", "${E.todayMin()}m")
            Card("chart", "TOTAL", "${E.total() / 60}h")
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.glass().fillMaxWidth().padding(18.dp)) {
            Text("LAST 7 DAYS", color = SOFT, fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(10.dp))
            Bars()
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.glass().fillMaxWidth().padding(18.dp)) {
            Text("SESSIONS HELD: ${E.sessions()}", color = WHITE, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text("THE HAND CLOSES AS YOU FOCUS.", color = SOFT, fontSize = 11.sp)
        }
    }
}

@Composable
fun Card(icon: String, label: String, value: String) {
    Column(Modifier.glass().weight(1f).padding(16.dp)) {
        Ic(icon, AMBER, 20)
        Spacer(Modifier.height(8.dp))
        Text(value, color = WHITE, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = SOFT, fontSize = 9.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun Bars() {
    val data = E.week()
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        data.forEachIndexed { i, v ->
            val a by animateFloatAsState(initialValue = 0f, targetValue = 1f, animationSpec = tween(700, delayMillis = i * 90))
            val max = (data.maxOrNull() ?: 1).coerceAtLeast(1)
            Column(Modifier.weight(1f)) {
                Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                    val bh = (size.height - 6f) * v / max * a
                    drawRoundRect(AMBER, Offset(0f, size.height - bh), Size(size.width, bh.coerceAtLeast(3f)), CornerRadius(6f))
                }
                Text("${v}m", color = SOFT, fontSize = 8.sp)
            }
        }
    }
}