package com.red.os

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.graphics.Path

@Composable
fun Backdrop(grab: Float) {
    val inf = rememberInfiniteTransition()
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)))
    val glow by inf.animateFloat(0.5f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse))
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFFE03434), Color(0xFF8A1116), Color(0xFF22040A))))
        drawRect(Brush.radialGradient(listOf(Color(0x00000000), Color(0xB0000000)), center = Offset(w / 2, h * 0.55f), radius = w * 0.9f))
        hand(Color(0xFFFF5A48).copy(alpha = 0.55f + glow * 0.3f), grab)
        hand(Color(0xFFB3141C).copy(alpha = 0.9f), grab)
        for (i in 0..13) {
            val speed = 0.35f + (i % 5) * 0.16f
            val yy = 1f - ((t * speed + i * 0.137f) % 1f)
            val xx = (0.06f + 0.88f * ((i * 0.618f) % 1f)) + 0.02f * kotlin.math.sin((t * 6.28f) + i)
            val alpha = (yy * 0.7f).coerceIn(0.05f, 0.6f)
            drawCircle(Color(0xFFFFB35C).copy(alpha = alpha), 2f + (i % 3) * 1.6f, Offset(w * xx, h * yy))
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.hand(c: Color, grab: Float) {
    val w = size.width; val h = size.height
    val cx = w / 2; val cy = h * 0.62f; val s = w / 420f
    drawOval(c, Offset(cx - 95 * s, cy - 75 * s), Size(190 * s, 225 * s))
    drawRoundRect(c, Offset(cx - 60 * s, cy - 30 * s), Size(120 * s, 130 * s), CornerRadius(45 * s))
    drawRoundRect(c, Offset(cx - 42 * s, cy + 80 * s), Size(84 * s, 300 * s), CornerRadius(40 * s))
    val fx = listOf(-46f, -23f, 0f, 23f, 46f)
    val fl = listOf(95f, 122f, 132f, 116f, 82f)
    fx.forEachIndexed { i, ox ->
        val spread = ox * (1f - grab * 0.55f)
        val len = fl[i] * (1f - grab * 0.38f)
        val px = cx + spread * s; val py = cy - 15 * s
        val p = Path()
        p.addRoundRect(RoundRect(px - 11 * s, py - len * s, px + 11 * s, py + 45 * s, CornerRadius(11 * s)))
        p.transform(Matrix().apply { translate(px, py); rotateZ(spread * 0.55f); translate(-px, -py) })
        drawPath(p, c)
    }
    val tp = Path()
    tp.addRoundRect(RoundRect(cx - 100 * s, cy - 5 * s, cx - 74 * s, cy + 85 * s, CornerRadius(13 * s)))
    tp.transform(Matrix().apply { translate(cx - 70 * s, cy + 10 * s); rotateZ(-28f - grab * 22f); translate(-(cx - 70 * s), -(cy + 10 * s)) })
    drawPath(tp, c)
}